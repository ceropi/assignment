<?php
//recieve info
$name = $_POST['name'];
$phone = $_POST['phone'];
$email = $_POST['email'];
$type = $_POST['type'];
$member = $_POST['member'];
$price = array(5000, 8000, 11000);
$total = caldiscount($member, $price, $type);
$discount = 0;


//random room number

//loop
for($i=0; $i<=2; $i++)
{
    $random_num = rand(1,2);
    $random_num1 = rand(0,9);
}

//selection
if($type == 'Standard')
{
    $random_floor = rand(1,2);
}
elseif($type == 'Superior')
{
    $random_floor = rand(3,4);
}
else
{
    $random_floor = rand(5,6);
}


//memberdiscount
function caldiscount($member, $price, $type)
{
        if($type == 'Standard')
        {
            if($member == 'none')
            {
                $dis = 1;
                $total = $price[0] * $dis;
            }
            elseif($member == 'silver')
            {
                $dis = 0.95;
                $total = $price[0] * $dis;
            }
            elseif($member == 'gold')
            {
                $dis = 0.93;
                $total = $price[0] * $dis;
            }
            else
            {
                $dis = 0.90;
                $total = $price[0] * $dis;
            }
        }
        elseif($type == 'Superior')
        {
            if($member == 'none')
            {
                $dis = 1;
                $total = $price[1] * $dis;
            }
            elseif($member == 'silver')
            {
                $dis = 0.95;
                $total = $price[1] * $dis;
            }
            elseif($member == 'gold')
            {
                $dis = 0.93;
                $total = $price[1] * $dis;
            }
            else
            {
                $dis = 0.90;
                $total = $price[1] * $dis;
            }
        }

        else
        {
            if($member == 'none')
            {
                $dis = 1;
                $total = $price[2] * $dis;
            }
            elseif($member == 'silver')
            {
                $dis = 0.95;
                $total = $price[2] * $dis;
            }
            elseif($member == 'gold')
            {
                $dis = 0.93;
                $total = $price[2] * $dis;
            }
            else
            {
                $dis = 0.90;
                $total = $price[2] * $dis;
            }
        }
    return $total;
}


//room price
if($type == 'Standard')
{
    $price = $price[0];
}
elseif($type == 'Superior')
{
    $price = $price[1];
}
else{
    $price = $price[2];
}


//discount %
if($member == 'plat')
{
    $discount = 10 ;
}
elseif($member == 'gold')
{
    $discount = 7 ;
}
elseif($member == 'silver')
{
    $discount = 5 ;
}
else
{
    $discount = 0 ;
}


//sequence Display
echo  "<h1>Infomation</h1><br>";
echo  "</br>Name : $name";
echo  "</br>Phone number : $phone";
echo  "</br>E-mail : $email";
echo  "</br>Room type : $type";
echo  "</br>Room number : $random_floor$random_num$random_num1";
echo  "</br>Member : $member";
echo  "</br></br>Price : $price Bath";
echo  "</br>Discount : $discount %";
echo  "</br>Total Price : $total Bath";
echo  "<br><br><br>";
echo  "Your Room :";
?>


<html>
    <head>
        <style>
            .table{
                
            }
        </style>
    </head>
    <body>
        <div class="table">
<?php
    for($i=1; $i<=1; $i++)
    {
        {
            for($j=1; $j<=2; $j++)
            {
                echo "<table border=1>
                <tr>
                <td> $random_floor{$j}0 </td>
                <td> $random_floor{$j}1 </td>
                <td> $random_floor{$j}2 </td>
                <td> $random_floor{$j}3 </td>
                <td> $random_floor{$j}4 </td>
                <td> $random_floor{$j}5 </td>
                <td> $random_floor{$j}6 </td>
                <td> $random_floor{$j}7 </td>
                <td> $random_floor{$j}8 </td>
                <td> $random_floor{$j}9 </td>
                </tr>
                </table>";
            }
        }
    }
?>
</div>
    
    </body>
</html>