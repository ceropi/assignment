<html>
    <body>
        <h1 align="center" >Tour Information</h1>
        <div align="center" ><?php
                session_start();
                $ans = $_POST["tour"];
                $total = 0;
                foreach($ans as $j => $ans1){
                    $sum1 = 0;
                    foreach($ans1 as $i => $ans2){
                        echo $i." = " ;
                        echo $ans2;
                        echo "<br>";
                        $sum1 = $ans2 + $sum1;
                    }
                    echo $j."Price = ".$sum1;
                    $total = $sum1 + $total;
                    echo"<br><br>";
                }
                    echo "FinalTotal = $total";
                    $_SESSION["fulltotal"] = $total;
            ?>
        </div>
    </body>
</html>
<html>
<head>
    <title>Tour</title>
    <style>
        html{
            background: url(photo/background.png) no-repeat center  fixed;
            background-size: cover;
            color: #FFFFFF;
        }
        a.button {
            text-decoration: none;
            color: white ;
        }
        .btn{
            background-color: red;
        }
        .btn1{
            background-color: green;
        }
    </style>
</head>
<body>
    <div align="center">
   <br><button class="btn">
            <a href="projecthome.html" class="button">Back To Home</a>
        </button>
        <button class="btn1">
        <a href="event.html" class="button">Booking Event</a>
        </button>
    </div>
</body>
</html>