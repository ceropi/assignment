<?php
$name = $_POST['id'];
$select = $_POST['select'];
$selectfunc = conditionevent($select);


session_start()
$_SESSION["name"] = $_POST['id'];
$_SESSION[""]
echo "<h1>Event</h1>";
echo "Name : $name <br><br>";


foreach($select as $i)
{
    echo "<b>$i</b><br>";
    echo conditionevent($i);
}


function conditionevent($select)
{
    if($select == 'Beach Voleyball')
    {
        echo " Start at : 13:00 - 15:00<br>";
    }
    elseif($select == 'Surf Festival')
    {
        echo " Start at : 15:00 - 18:00<br>";
    }
    elseif($select == 'Prom Night')
    {
        echo " Start at : 18:00 - 21:00<br>";
    }
    elseif($select == 'Full Moon Party')
    {
        echo " Start at : 21:00 - 00:00<br>";
    }
}


echo "<br><br><br><br>";
echo "<h3>*****You shoud ready before The first event start 30 minute*****</h3>";
?>



!