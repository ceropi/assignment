<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="Lab_13_3_2.php" method="post">
        <h1>Sum of student scores</h1>
        <?php for($i=0; $i<(int)$_GET['t']; $i++) { ?>
            <h2>Test <?php echo $i+1 ?></h2>
        <?php for($j=0; $j<(int)$_GET['c']; $j++) {?>
            Couse <?php echo $j+1 ?> :
            <input type="text" name="Couse[<?= $i ?>][<?= $j ?>]"><br>
            <?php } ?>
            <?php } ?>
            <br>
            <input type="submit" value="Submit">
    </form>
</body>
</html>