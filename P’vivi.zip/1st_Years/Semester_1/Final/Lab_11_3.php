<?php
$text = $_POST['text'];
$alp1 = $_POST['alp1'];
$alp2 = $_POST['alp2'];
$count1 = findingalp($text, $alp1);
$count2 = findingalp($text, $alp2);


echo "<h2>Find alphabets in a word</h2>";
echo "Word = $text <br>";
echo "#1 Alphabet = $alp1 <br>";
echo "#2 Alphabet = $alp2 <br><br>";
echo "$alp1 was found in the word $text = $count1 time(s)<br>";
echo "$alp2 was found in the word $text = $count2 time(s)<br>";


function findingalp($t, $a1)
{
    $a = 0;
    for($i=0; $i<=strlen($t); $i++){
        if(substr($t,$i,1) == "$a1")
            $a = $a + 1;
    }
    return $a;
}
?>