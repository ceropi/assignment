<?php
$v = $_POST['value'];
$r = $_POST['rounds'];
$total = 0;

for($a=1;$a<=$r;$a++)
{
    echo "Multiplication $v x 12 <br>";
        for($j=1;$j<=12;$j++)
            {
                $total = $v * $j;
                echo "$v x $j = $total <br>";
            }
    echo "<br>";
    $v = $v + 1;
}
?>