<html>
<body>
    <form action="Lab_12_3_2.php" method="post">
        <h1>Company Income (Million)</h1>  
        <?php for($i = 0; $i < (int)$_GET['n']; $i++) { ?>
        Month <?= $i + 1 ?>
        <input type="text" name="month[]" />
        <br>
        <?php } ?>
        <br><br>
        <input type="submit" value="Submit">
    </form>
</body>
</html>