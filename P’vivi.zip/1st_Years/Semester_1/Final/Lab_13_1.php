<?php
$person = array('dave' => "75", 'shawn' => "80",
    'sarah' => "77", 'jessy' => "65", 'mona' => "85");

    
foreach($person as $key => $value)
{
    echo "Student name = $key <br>";
    echo "Score = $value<br>";

    if($value >= 80)
        echo "Result = Get A";
    else
        echo "Result = Not get A";
    
    echo "<br><br>";
}
?>