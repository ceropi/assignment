<?php
    $start = $_POST["Start"];
    $end = $_POST["End"];
    $in = $_POST["In"];



    for($start=0; pow($start,2); $start+=5){
        echo "<table border =1>
        <tr>
            <th> The Square of </th>
            <th> Result </th>
        </tr>
        <tr>
            <td> $in </td>
            <td> $start </td>
        </tr>
        </table>"
    }
?>