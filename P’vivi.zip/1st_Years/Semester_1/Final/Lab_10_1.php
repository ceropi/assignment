<?php
$r = $_POST['rounds'];
$a = 0;
$b = 0;
$c = 0;

for($i=1; $i<=$r; $i++)
{
    $ran = rand(1,3);

    echo "Random number #$i ==> $ran <br>";

    if($ran == 1)
    {
        $a = $a + 1;
    }
    elseif($ran == 2)
    {
        $b = $b + 1;
    }
    else
    {
        $c = $c + 1;
    }
}
echo "<br><br>";

echo "Count for 1  = $a time(s)<br>";
echo "Count for 2  = $b time(s)<br>";
echo "Count for 3  = $c time(s)";
?>