<?php
$num = $_POST["i"];


echo "<h2>Multiplication Table</h2>";
    $i = 1;
    $total = 0;
    do {
        $total = $num * $i;
        echo "<br>$num x $i = $total";
        $i++;
    }
    while($i<=12)
?>    