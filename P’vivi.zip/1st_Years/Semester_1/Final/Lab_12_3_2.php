<html>
    <body>
        <h1>Company Income Graph</h1><br>
        <?php foreach($_POST['month'] as $i => $month) { ?>
        <?php for($i = 0; $i <= $month; $i++)
                {
                    for($i = 1; $i<=$month; $i++)
                    {
                        echo "*";
                    }
                    $month++;
                    echo "<br>";
                } ?>
        <br>
        <?php } ?>
    </body>
</html>