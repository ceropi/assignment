<?php
$select = $_POST['select'];
$text = $_POST['text'];


if($select == "text")
{
    echo "Your option : Count the length of text<br>";
    echo "Your result : ".strlen($text);
}
elseif($select == "words")
{
    echo "Your option : Count the length of words<br>";
    echo "Your result : ".str_word_count($text);
}
elseif($select == "uppercase")
{
    echo "Your option : Convert text to uppercase<br>";
    echo "Your result : ".strtoupper($text);
}
else
{
    echo "Your option : Convert text to lowercase<br>";
    echo "Your result : ".strtolower($text);
}
?>