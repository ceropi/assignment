<?php
$ID = $_POST['ID'];
$Sub = $_POST['Subtotal'];
$Late = $_POST['Late'];
$charge = 0;
$total = 0;

echo "<h2>Change For late car return</h2><br>";

$date = date("d F y");
echo "Return date = $date<br>";
echo "Rent ID = $ID<br>";
echo "Subtotal = ".number_format($Sub,2)."baht<br>";
echo "Numbers of late hours = ".ceil($Late)."hours<br>";

if($Late <= 4)
    $a = 0.50;
elseif($Late <= 8)
    $a = 0.70;
else
    $a = 1.00;

$charge = $Sub * $a;
echo "Charges = ".number_format($charge,2)."baht<br><br>";

$total = $Sub + $charge;
echo "<h2>Total = ".number_format($total,2)."baht</h2>"
?>