<?php
$sum0ftest = [];


foreach($_POST['Couse'] as $row)
{
    $sum=0;
    foreach($row as $colum)
    {
        $sum = $sum + (int)$colum;
    }
    $sum0ftest[] = ['total' => $sum];
}
?>


<html>
    <head><title>Sum of student scores</title></head>
<body>
    <h2>Sum of student scores</h2>
    <?php foreach($sum0ftest as $i => $num) { ?>
        <h3>Row <?php echo $i + 1 ?></h3>
        Total : <?php echo $num['total'] ?><br>
    <?php } ?>
</body>
</html>