<?php
$Lnum = 8;
$correct = 0;


echo "Random - ";
for($i=1;$i<=3;$i++)
{
    $random = rand(1,9);
    echo "$random ";
    if($random == $Lnum)
    {
        $correct = 8; 
    }
}
if($correct == $Lnum)
{
    echo "<br>You are the Winner!!! <br>";
    echo "Answer is $Lnum";
}
else
{
    echo "<br>You are the Loser <br>";
    echo "Try again";
}
?>