<?php
$option1 = $_POST['option1'];
$option2 = $_POST['option2'];
$weight = $_POST['Weight'];
$weight2 = $_POST['Weight2'];
$package1 = calprice($option1, $weight);
$package2 = calprice($option2, $weight2);
$result = 0;


echo "<h1>Shipping Cost Calculator</h1>";
echo "<h2>========== Package 1 ==========</h2>";
echo "Shipping option = $option1 <br>";
echo "Weight = $weight Kg.<br>";
echo "Shiping cost = $package1";


function calprice($option, $weight)
{
if($option=="Domestic")    
{
    if($weight < 5)
    {
        $cos_per_kg = 10;
    }
    else
    {
        $cos_per_kg = 15;
    }
}
else
{
    if($weight < 5)
    {
        $cos_per_kg = 100;
    }
    else
    {
        $cos_per_kg = 150;
    }
}
$result = $cos_per_kg * $weight;
return $result;
}


echo "<br><br>";


echo "<h2>========== Package 2 ==========</h2>";
echo "Shipping option = $option2 <br>";
echo "Weight = $weight2 Kg.<br>";
echo "Shiping cost = $package2";


?>