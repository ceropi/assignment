<?php
$diatance = $_POST['diatance'];
$time = $_POST['time'];
$unit = $_POST['unit'];
$result = 0;
$result = calspeed($diatance, $time, $unit);


echo "<h2>Speed Calculator</h2>";
echo "Distance = $diatance m.<br>";
echo "Time = $time s.<br>";


function calspeed($diatance, $time, $unit)
{
    if($unit=="Yes")
    {
        $result = ($diatance/1000) / ($time/3600);
    }
    else
    {
        $result = $diatance / $time;
    }
    return $result;
}


echo "Change Unit to km/h = $unit<br>";
    echo "Speed = $result km/h";
?>