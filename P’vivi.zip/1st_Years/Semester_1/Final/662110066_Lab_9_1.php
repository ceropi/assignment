<?php
$r = $_POST['rows'];
$l = $_POST['layers'];

for($a=1; $a<=$l; $a++)
    for($i=1; $i<=$r; $i++)
    {
        for($j=1; $j<=$i; $j++)
        {
            echo "* ";
        }
        echo "<br>";
    }
?>