<?php
    $id = $_POST['id'];
    $name = $_POST['name'];
    $major = $_POST['major'];
    $s1 = $_POST['sub1'];
    $s2 = $_POST['sub2'];
    $s3 = $_POST['sub3'];
    $s4 = $_POST['sub4'];
    $s5 = $_POST['sub5'];

    $gpa = calgpa($s1, $s2, $s3, $s4, $s5);

    $status = findstatus($gpa);

    show($id, $name, $major, $gpa, $status);

    function calgpa($g1, $g2, $g3, $g4, $g5)
    {
        $result = (($g1*3)+($g2*3)+($g3*3)+($g4*3)+($g5*3))/15;
        return $result;
    }

    function findstatus($gpa)
    {
        if($gpa >= 2.00)
            $stt = "GPA -- Normal";
        else
            $stt = "GPA -- Must equal or greater than 2.00";
        return $stt;
    }

    function show($i, $n, $m, $g, $s)
    {
        echo "<h3> Student Information</h3>";
        echo "Student ID: $i <br>";
        echo "Name: $n <br>";
        echo "Major: $m <br><br>";
        echo "GPA: ".number_format($g,2)." <br>";
        echo "Status: $s";
    }
?>