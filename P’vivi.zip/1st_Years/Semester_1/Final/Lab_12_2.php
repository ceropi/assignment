<?php
$id = $_POST['ID'];
$select = $_POST['type'];
$soup = $_POST['soup'];
$top = $_POST['top'];


echo "<h2>Noodle Order Summary</h2>";
echo "Older ID $id <br>";
echo "Noodle type $select <br>";
echo "Noodle soup $soup <br>";


foreach($top as $i)
    {   
        echo "Noodle toppings $i <br>";
    }
?>