<?php
$num = array(15, 40, 60, 12, 34);
$max = 0;
$index = 0;


//finding max & index
for($i=0; $i<sizeof($num); $i++)
{
        if($num[$i] >= $max)
        {
        $max = $num[$i];
        $index = $i;
        }
}


//loop array
for($i=0; $i<sizeof($num);$i++)
{
    echo $num[$i]."<br>";
}


//display
echo "<br>Max number = $max";
echo "<br>Index = $index";
?>