<?php
$test[0] = array(10,9,9);
$test[1] = array(8,8,7);
$sum = array(0,0);


for($i=0; $i<sizeof($test); $i=$i+1)
{   

    for($j=0; $j<sizeof($test[$i]); $j=$j+1)
    {
        $sum[$i] = $sum[$i] + $test[$i][$j];
    }
    $num_test = $i + 1;
    echo "Sum of test $num_test = $sum[$i] <br>";
}
?>