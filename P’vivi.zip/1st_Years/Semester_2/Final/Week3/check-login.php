<?php
session_start();
include "config.php";

$userQuery = "SELECT * FROM systemuser AS u INNER JOIN employee AS e ON u.employee_id = e.employee_id 
    WHERE username LIKE'".$_POST['username']. "'";

$result=mysqli_query($connect, $userQuery);
 if(!$result){
    die("Could not successfully run the query".mysqli_error($connect));
 }
 if(mysqli_num_rows($result) == 0){
    $_SESSION['errors_msg'] = "Username or Password is incorrect";
    header("location:login.php");
 }
 else{
    $row = mysqli_fetch_assoc($result);
    if (($_POST['username']==$row['username']) && ($_POST['password']==$row['password'])) {
    $_SESSION['username']=$row['username'];
    $_SESSION['firstname']=$row['firstname'];
    $_SESSION['lastname']=$row['lastname'];
    $_SESSION['level']=$row['level'];
    header("Location: index.php");
    }
    else{
        $_SESSION['errors_msg'] = "Username or Password is incorrect";
        header("location:login.php");
    }
 }
?>