<div class="footer">
    cobyright &copy2012 college of Arts, media and Technology, Chiang Mai University
</div>