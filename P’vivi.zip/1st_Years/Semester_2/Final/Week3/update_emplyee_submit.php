<?php
require_once "config.php";

$employee_id = $_GET['id'];

$Fname = $_POST['Fname'];
$Lname = $_POST['Lname'];
$salary = $_POST['salary'];

$userQuery = "UPDATE employee SET firstname = '$Fname',
                                lastname = '$Lname',
                                salary = '$salary'
                WHERE employee_id = '$employee_id'";

$result = mysqli_query($connect, $userQuery);   

if(!$result){
    die('FAILED');
}
else{
    header('location: showEmplyee.php');
}
?>