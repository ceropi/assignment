<?php
include_once "config.php";
?>
<?php require_once "header.php"; ?>
<html>
    <head>
    </head>
    
    <body>
    <div class="form">
    <div class="php">
    <?php 
    if(isset($_SESSION['errors_msg'])){
    echo $_SESSION['errors_msg'];  //Username or Password is incorrect
    }
    ?>
     </div>
        <form action="check-login.php" method="post">
            <table class="table">
                <tr><td>Username: </td><td><input type="text" name="username"></td></tr>
                <tr><td>Password: </td><td><input type="password" name="password"></td></tr>
            </table><br>
            <input type="submit" value="Submit"><input type="reset" value="Reset">
        </form>
    </body>
    </div>
</html>
<?php require_once "footer.php";?>