<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add employee</title>
</head>

<body>
<?php require_once "config.php"; ?>
<?php require_once "header.php"; ?>

<?php if($_SESSION['level']==4) { ?>
    <form action="add_position.php" method="post">
        <div class="head">
            <h2>Add new position</h2>
        </div>
        <table>
            <tr>
                <th><label for="text">Position_id</label></th>
                <td>Auto_increment</td>
            </tr>
            <tr>
                <th><label for="text">Position name</label></th>
                <td><input type="text" name="Pname"></td>
            </tr>
        </table><br>
        <input type="submit" value="Submit">
    </form>
    <?php } 
    else {
        echo "<h3 class='error'>You are unable to access the data, please try again</h3>"; 
    } ?>
</body>

</html>