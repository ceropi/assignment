<?php
require_once "config.php";

$Dname = $_POST['Dname'];

$userQuery = "INSERT INTO department VALUES ('','$Dname')";
$result = mysqli_query($connect,$userQuery);

if(!$result){
    die("Could not successfully run the query $userQuery".mysqli_error($connect));
}
else{
    header("location: showDepartment.php");
}
?>