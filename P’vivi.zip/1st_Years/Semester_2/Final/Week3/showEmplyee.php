<html>
    <body>
        <?php
            require_once "header.php";
            require_once "config.php";
        ?>
        <h2>Employee Management</h2>
        <div class="main-content">
            <?php

                $userQuery = "SELECT count(*) AS total FROM employee";
                $result = mysqli_query($connect, $userQuery);
                $row = mysqli_fetch_assoc($result);
                $count = $row['total'];
                $userQuery = "SELECT * FROM employee";
                $result = mysqli_query($connect, $userQuery);
                if(!$result){
                    die("could not successfully run the query $userQuery".mysqli_error($connect));
                }
                if($_SESSION['level']>0){
                    if($_SESSION['level']==2){
                        echo '<a href="add_employee_form.php">Create new employee</a>';
                    }
            ?>
            <table border="1">
                <tr>
                    <th>ID</th>
                    <th>Firstname</th>
                    <th>Lastname</th>

                    <?php
                    if($_SESSION['level']!=1 && $_SESSION['level']!=4){
                        echo "<th>Salary</th>";
                    }
                    if($_SESSION['level']==3){
                        echo "<th>Action</th>";
                    }
                    ?>
                </tr>
                    <?php
                    if(mysqli_num_rows($result)==0){
                        echo "<td colspan='3'>No records were found</td>";
                    }
                    else{
                        while($row = mysqli_fetch_assoc($result)) {
                            echo "<tr>";
                            echo "  <td>".$row['employee_id']."</td>";
                            echo "  <td>".$row['firstname']."</td>";
                            echo "  <td>".$row['lastname']."</td>";
                            if($_SESSION['level']!=1 && $_SESSION['level']!=4){
                                echo "<td>".$row['salary']."</td>";
                            }
                            if($_SESSION['level']==3){
                                echo "<td><a href='update_employee.php?id=".$row['employee_id']."'>EDIT</a>&nbsp;&nbsp;
                                <a href='delete_employee.php?id=".$row['employee_id']."'>Delete</a></td>";
                            }
                            echo "</tr>";
                        }
                    } ?>
                <tr>
                    <td colspan="5"><?= $count ?> Records </td>
                </tr>
            </table>
            <?php  }else {
                echo "<h3 class='error'>You are unable to access the data, please try again</h3>";
            }
            ?>
        </div>
    </body>
</html>