<?php
require_once "config.php";

$Fname = $_POST['Fname'];
$Lname = $_POST['Lname'];
$salary = $_POST['salary'];

$userQuery = "INSERT INTO employee VALUES ('','$Fname','$Lname','$salary')";
$result = mysqli_query($connect,$userQuery);

if(!$result){
    die("Could not successfully run the query $userQuery".mysqli_error($connect));
}
else{
    header("location: showEmplyee.php");
}
?>