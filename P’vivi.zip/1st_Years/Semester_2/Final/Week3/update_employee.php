<?php
require_once "config.php";

$employee_id = $_GET['id'];
$userQuery = "SELECT * FROM employee WHERE employee_id = $employee_id";
    $result = mysqli_query($connect, $userQuery);

    if(!$result){
        die("Could not successfully run the query $userQuery".mysqli_error($connect));
    }
    else{
        echo "Update data<br><br>";
        while ($row = mysqli_fetch_assoc($result)){
?>
<html>
    <body>
        <form action="update_emplyee_submit.php?id=<?php echo $employee_id; ?>" method="post">
            <table width="416" border=0>
                <tr>
                    <td width="160">Employee_ID</td>
                    <td width="246">Auto_increment</td>
                </tr>
                <tr>
                    <td>First name</td>
                    <td><input type="text" name="Fname" value="<?=$row['firstname'] ?>"></td>
                </tr>
                <tr>
                    <td>Last name</td>
                    <td><input type="text" name="Lname" value="<?php echo $row['lastname'] ?>"></td>
                </tr>
                <tr>
                    <td>Salary</td>
                    <td><input type="text" name="salary" value="<?php echo $row['salary'] ?>"></td>
                </tr>
                <tr>
                    <td align="right"><input type="submit" name="button" values="Submit"></td>
                    <td><input type="reset" name="button2" values="Cancel"></td>
                </tr>
            </table>
        </form>
    </body>
</html>
<?php
        }
    }
?>