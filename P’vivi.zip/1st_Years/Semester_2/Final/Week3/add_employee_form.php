<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add employee</title>
</head>

<body>
    <?php require_once "header.php"; ?>
    <?php require_once "config.php"; ?>

    <?php if($_SESSION['level']!=3) { ?>
    <form action="add_employee.php" method="post">
        <div class="head">
            <h2>Add new employee</h2>
        </div>
        <table>
            <tr>
                <th><label for="text">Employee_id</label></th>
                <td>Auto_increment</td>
            </tr>
            <tr>
                <th><label for="text">First name</label></th>
                <td><input type="text" name="Fname"></td>
            </tr>
            <tr>
                <th><label for="text">Last name</label></th>
                <td><input type="text" name="Lname"></td>
            </tr>
            <tr>
                <th><label for="text">Salary</label></th>
                <td><input type="text" name="salary"></td>
            </tr>
        </table><br>
        <input type="submit" value="Submit">
        <?php } 
        else { 
            echo "<h3 class='error'>You are unable to access the data, please try again</h3>"; 
        } ?>
    </form>
</body>

</html>