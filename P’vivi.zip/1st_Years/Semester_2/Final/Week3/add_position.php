<?php
require_once "config.php";

$Pname = $_POST['Pname'];

$userQuery = "INSERT INTO position_t VALUES ('','$Pname')";
$result = mysqli_query($connect,$userQuery);

if(!$result){
    die("Could not successfully run the query $userQuery".mysqli_error($connect));
}
else{
    header("location: showPosition.php");
}
?>