<?php session_start(); ?>


<head>
    <link rel="stylesheet" type="text/css" href="main2.css">  
</head>

<div class="header">
    <h1 class="header">Web Database System</h1>
    <ul class="nav">
        <li><a href="index.php">Home</a></li>
        <li><a href="showPosition.php">Position</a></li>
        <li><a href="showDepartment.php">Department</a></li>
        <li><a href="showSystemuser.php">System-user</a></li>
        <li><a href="showEmplyee.php">Employee</a></li>
        <?php
            if(isset($_SESSION['username'])){
                echo '<li><a href="logout.php   ">Logout - </a>';
                echo "<span class='user-desc'>&nbsp;[";
                echo $_SESSION['firstname']
                    ." ".$_SESSION['lastname']
                    ." - level: ".$_SESSION['level'];
                echo "]</span></li>";
            }
            else{
                echo '<li><a href="login.php">Login</a></li>';
            }
        ?>
    </ul>
</div>