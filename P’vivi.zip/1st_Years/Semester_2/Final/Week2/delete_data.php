<?php
require_once "config.php";

$travel_id = $_GET['id'];

$userQuery = "DELETE FROM travel WHERE travel_id = '$travel_id'";
$result = mysqli_query($connect, $userQuery);

if(!$result){
    die("DELETE FAILED");
}
else{
    header('location: display_report.php');
}
?>