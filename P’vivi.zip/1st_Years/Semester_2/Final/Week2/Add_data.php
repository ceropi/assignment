<?php
require_once "config.php";

$select = $_POST['travel'];
$people = $_POST['numberOfpeople'];
$night = $_POST['numberOfstaying'];
$airfare = 0;
$hotel = 0;
$hotelPrice = 0;
$ticketPrice = 0;
$totalPrice = 0;

//Cal airfare & hotel cost
if($select == "Bacelona"){
    $airfare = 875;
    $hotel = 85;
}
elseif($select == "Cairo"){
    $airfare = 950;
    $hotel = 98;
}
elseif($select == "Rome"){
    $airfare = 875;
    $hotel = 110;
}
elseif($select == "Santiago"){
    $airfare = 820;
    $hotel = 85;
}
else{
    $airfare = 1575;
    $hotel = 240;
}

$hotelPrice = $airfare * $night;
$ticketPrice = ($hotel * $people) * $night;
$totalPrice = $hotelPrice + $ticketPrice;

$userQuery = "Insert into travel values ('','$select','$night','$people','$hotelPrice','$ticketPrice','$totalPrice')";
$result = mysqli_query($connect,$userQuery);

if(!$result){
    die("Could not successfully run the query $userQuery".mysqli_error($connect));
}
else{
    header("location: display_report.php");
}

mysqli_close($connect)
?>