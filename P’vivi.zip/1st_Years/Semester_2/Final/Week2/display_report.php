<?php
echo "<a href=Travel.html>Add a new travel</a><br><br>";
require_once "config.php";

$userQuery = "Select * From travel";
$result = mysqli_query($connect, $userQuery);

if(!$result){
    die("Could not successfully run the query $userQuery ".mysqli_error($connect));
}

if(mysqli_num_rows($result) == 0){
    echo "No record were found with query $userQuery";
}
else{
    echo "<table border=1>";
    echo "<tr><th>Destination</th>
        <th>Number Of night</th>
        <th>Number Of people</th>
        <th>Hotel Price</th>
        <th>Ticket Price</th>
        <th>Total Price</th>
        <th>Update</th>
        <th>Delete</th></tr>";
    while($row = mysqli_fetch_assoc($result)){
        echo "<tr><td>$row[destination]</td>
            <td>$row[NumberOfNight]</td>
            <td>$row[NumberOfPeople]</td>
            <td>$row[HotelPrice]</td>
            <td>$row[TicketPrice]</td>
            <td>$row[TotalPrice]</td>
            <td><a href=update_data.php?id=".$row['travel_id'].">Update</a></td>
            <td><a href=delete_data.php?id=".$row['travel_id'].">Delete</a></td>
            </tr>";
    }
    echo "</table>";
}
?>