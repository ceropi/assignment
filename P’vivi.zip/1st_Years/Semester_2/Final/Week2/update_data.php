<?php
    require_once "config.php";

    $travel_id = $_GET['id'];

    $userQuery = "Select * from travel where travel_id = $travel_id";
    $result = mysqli_query($connect, $userQuery);

    if(!$result){
        die("Could not successfully run the query $userQuery".mysqli_error($connect));
    }
    else{
        echo "Update data<br><br>";
        while ($row = mysqli_fetch_assoc($result)){
?>
<html>
    <body>
        <form action="update_data_submit.php?id=<?php echo $travel_id; ?>" method="post">
            <table width="416" border=0>
                <tr>
                    <td width="160">Travel_ID</td>
                    <td width="246">Auto_increment</td>
                </tr>
                <tr>
                    <td>Destination</td>
                    <td><input type="text" name="Destination" value="<?=$row['destination'] ?>"></td>
                </tr>
                <tr>
                    <td>Number of night</td>
                    <td><input type="text" name="NumberOfNight" value="<?php echo $row['NumberOfNight'] ?>"></td>
                </tr>
                <tr>
                    <td>Number of people</td>
                    <td><input type="text" name="NumberOfPeople" value="<?php echo $row['NumberOfPeople'] ?>"></td>
                </tr>
                <tr>
                    <td>Hotel Price</td>
                    <td><input type="text" name="HotelPrice" value="<?php echo $row['HotelPrice'] ?>"></td>
                </tr>
                <tr>
                    <td>Ticket Price</td>
                    <td><input type="text" name="TicketPrice" value="<?php echo $row['TicketPrice'] ?>"></td>
                </tr>
                <tr>
                    <td>Total Price</td>
                    <td><input type="text" name="TotalPrice" value="<?php echo $row['TotalPrice'] ?>"></td>
                </tr>
                <tr>
                    <td align="right"><input type="submit" name="button" values="Submit"></td>
                    <td><input type="reset" name="button2" values="Cancel"></td>
                </tr>
            </table>
        </form>
    </body>
</html>
<?php    
        }
    }
?>