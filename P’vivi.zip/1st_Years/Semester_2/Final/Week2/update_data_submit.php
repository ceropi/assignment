<?php
require_once "config.php";

$travel_id = $_GET['id'];

$Destination = $_POST['Destination'];
$NumberOfNight = $_POST['NumberOfNight'];
$NumberOfPeople = $_POST['NumberOfPeople'];
$HotelPrice = $_POST['HotelPrice'];
$TicketPrice = $_POST['HotelPrice'];
$TotalPrice = $_POST['TotalPrice'];

$userQuery = "UPDATE travel SET destination = '$Destination',
                                NumberOfNight = '$NumberOfNight',
                                NumberOfPeople = '$NumberOfPeople',
                                HotelPrice = '$HotelPrice',
                                TicketPrice = '$TicketPrice',
                                TotalPrice = '$TotalPrice'
                WHERE travel_id = '$travel_id'";

$result = mysqli_query($connect, $userQuery);

if(!$result){
    die('FAILED');
}
else{
    header('location: display_report.php');
}
?>