<?php
    echo "<a href=form_add_product.html>Add a new product</a><br><br>";
    require_once "config.php";

    $userQuery = "Select * From product";
    $result = mysqli_query($connect, $userQuery);

    if(!$result){
        die ("Could not successfully run the query $userQuery ".mysqli_error($connect));
    }

    if(mysqli_num_rows($result) == 0){
        echo "No record were found with query $userQuery";
    }
    else{
        echo "<table border=1>";
        echo "<tr><th>Product_id</th><th>Product_name</th><th>Product_price</th><th>Product_QTY</th></tr>";
        while($row = mysqli_fetch_assoc($result)){
            echo "<tr><td>$row[product_ID]</td>
            <td>$row[product_name]</td>
            <td>$row[product_price]</td>
            <td>$row[product_QTY]</td></tr>";
        }
        echo "</table>";
    }
?>