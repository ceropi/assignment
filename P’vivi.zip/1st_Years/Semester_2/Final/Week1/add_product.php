<?php
require_once "config.php";

$name = $_POST['name'];
$price = $_POST['price'];
$qty = $_POST['qty'];

$userQuery = "Insert into product values ('','$name','$price','$qty')";
$result = mysqli_query($connect,$userQuery);

if(!$result){
    die("Could not successfully run the query $userQuery".mysqli_error($connect));
}
else{
    echo "Successfully added the new product <br>";
    echo "<a href=display_product.php>Go back to display all products</a>";
}

mysqli_close($connect);
?>