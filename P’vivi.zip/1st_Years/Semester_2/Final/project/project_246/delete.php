<?php
require_once "config.php" ; 
$id = $_GET['id'];

$query = "DELETE FROM mails WHERE mail_id = $id";
$result = mysqli_query($conn,$query);
if(!$result)
{
    die('Mail not exists');
}
else {
    header('location:mails.php');
}
?>