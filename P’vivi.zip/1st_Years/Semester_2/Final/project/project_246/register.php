<?php 
    session_start();
    include('config.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <link rel="stylesheet" href="register.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <title>Registration</title>
</head>
<body>

    <div class="wrapper">
        <form action="register_db.php" method="post">
            <?php include('errors.php'); ?>
            <?php if (isset($_SESSION['error'])) : ?>
                <div class="error">
                    <h3>
                        <?php
                            echo $_SESSION['error'];
                            unset($_SESSION['error']);
                        ?>
                    </h3>
                </div>
            <?php endif ?>

            <h1>Registration</h1>

            <div class="input-box">
                <div class="input-field">
                    <input type="text" name="fullname" placeholder="Full Name" required>
                    <i class='bx bxs-user-detail' ></i>
                </div>
                <div class="input-field">
                    <input type="text" name="username" placeholder="Username" required>
                    <i class='bx bxs-user-account' ></i>
                </div>
            </div>

            <div class="input-box">
                <div class="input-field">
                    <input type="email" name="email" placeholder="Email" required>
                    <i class='bx bxs-envelope' ></i>
                </div>
                <div class="input-field">
                    <input type="text" name="phone" placeholder="Phone Number" required>
                    <i class='bx bxs-phone' ></i>
                </div>
            </div>

            <div class="input-box">
                <div class="input-field">
                    <input type="password" name="password" placeholder="Password" required>
                    <i class='bx bxs-lock' ></i>
                </div>
                <div class="input-field">
                    <input type="password" name="confirm" placeholder="Confirm Password" required>
                    <i class='bx bxs-lock' ></i>
                </div>
            </div>

            <label><input type="checkbox"> I agree to the terms and conditions.</label>

            <button type="submit" name="reg_user" class="btn">Register</button>

            <p>Already have an account? <a href="login.php">Login here</a></p>
        </form>
    </div>
</body>
</html>