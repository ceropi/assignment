<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <link rel="stylesheet" href="course.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <title>Course</title>
</head>
<body>
    <div class="header">
        <div class="header-logo">
            <a href="home.php"><img src="image/Logo.png" width="50px" height="50px"></a>
            <p><a href="home.php">LearnHUB.</a></p>
        </div>
        <div class="header-menu">
            <ul>
                <li><a href="home.php">Home</a></li>
                <li><a href="course.php">Course</a></li>
                <li><a href="grade.php">Grade</a></li>
                <li><a href="contact.php">Contact</a></li>
            </ul>
        </div>
        <div class="header-icon">
            <a href="myprofile.php"><i class='bx bx-user-circle'></i></a>
        </div>
    </div>
    
    <?php 
            require_once "login_db.php";
            require_once "config.php" ;
            if(!isset($_SESSION['username'])){ ?>
                <div class="wrapper">
                    <p class="warning">You are not signed in.</p>
                </div>
    <?php }  else { ?>
        <div class="main-content">
            <ul>
                <div class="sub-content1">
                    <li>
                        <div class="course-name">
                            <a href="math.php">Mathematics</a>
                        </div>
                        <div class="describe">
                            <a href="">Secondary level mathematics content, There are 16 chapters in total.</a>
                        </div>
                    </li>
                    <li>
                        <div class="course-name">
                            <a href="science.php">Science</a>
                        </div>
                        <div class="describe">
                            <a href="">There are 4 science lessons.</a>
                        </div>
                    </li>
                    <li>
                        <div class="course-name">
                            <a href="social.php">Social</a>
                        </div>
                        <div class="describe">
                            <a href="">There are 7 social lessons.</a>
                        </div>
                    </li>
                </div>
                <div class="sub-content2">
                    <li>
                        <div class="course-name">
                            <a href="english.php">English</a>
                        </div>
                        <div class="describe">
                            <a href="">There are 5 English lessons, consisting of: grammar, listening, writing, speaking, reading.</a>
                        </div>
                    </li>
                    <li>
                        <div class="course-name">
                            <a href="thai.php">Thai</a>
                        </div>
                        <div class="describe">
                            <a href="">There are 11 chapters in total.</a>
                        </div>
                    </li>
                    <li>
                        <div class="course-name">
                            <a href="pe.php">Physical Education</a>
                        </div>
                        <div class="describe">
                            <a href="">There are 5 chapters in total.</a>
                        </div>
                    </li>
                </div>
            </ul>
        </div>
    <?php } ?>
</body>
</html>