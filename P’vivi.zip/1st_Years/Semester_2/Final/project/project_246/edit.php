<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="edit.css">
    <title>Edit Information</title>
</head>
<body>
<?php
      session_start();
      require_once "config.php";
      $sql = "SELECT * FROM user" ;
      $query = mysqli_query($conn,$sql);
?>

<h1>Edit infomation</h1>

<form action="save.php" method="post">
    <table width="284" border="1">
    <tr>
    <th width="120">ID</th>
    <td width="238"><input type="hidden" name="id" size="20" value="<?php echo $_POST["id"];?>"><?php echo $_POST["id"];?> </td>
    <tr>
    <th width="120">Username</th>
    <td width="238"><input type="text" name="user" size="30" value="<?php echo $_POST["name"];?>"> </td>
    </tr>
    <tr>
    <th width="120">Password</th>
    <td width="238"><input type="text" name="pass" size="30" value="<?php echo $_POST["pass"];?>"></td>
    </tr>
    <tr>
    <th width="120">Full Name</th>
    <td width="238"><input type="text" name="fname" size="30" value="<?php echo $_POST["fname"];?>"></td>
    </tr>
    <tr>
    <th width="120">Email</th>
    <td width="238"><input type="text" name="email" size="30" value="<?php echo $_POST["email"];?>"></td>
    </tr>
    <tr>
    <th width="120">Telephone</th>
    <td width="238"><input type="text" name="tel" size="30" value="<?php echo $_POST["tel"];?>"></td>
    </tr>
    </table>
    <div class="footer">
        <input type="submit" name="submit" value="Confirm edit" class="update">
        <a href="myprofile.php">Back to my profile</a>
    </div>
    </form>
<?php
mysqli_close($conn);
?>
</body>
</html>