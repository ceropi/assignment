<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <title>Save Information</title>
</head>
<body>
<?php
require_once "config.php";
$sql = " UPDATE user SET 
user_FullName = '".$_POST["fname"]."',
user_Name = '".$_POST["user"]."',
user_email = '".$_POST["email"]."',
user_phone_number = '".$_POST["tel"]."',
user_password = '".$_POST["pass"]."'
WHERE user_id = '".$_POST["id"]."'";

$query = mysqli_query($conn,$sql);
if($query)
{
echo "Update Success";
header('location: myprofile.php');
}
else
{
echo "Fail To Update";
} ?>
</body>
</html>