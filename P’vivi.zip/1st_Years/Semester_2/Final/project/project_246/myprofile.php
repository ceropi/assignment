<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <link rel="stylesheet" href="myprofile.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <title>My Profile</title>
</head>
<?php 
require_once "login_db.php";
require_once "config.php" ;
$userQuery = "SELECT * FROM user WHERE user_id";
$result = mysqli_query($conn,$userQuery);
?>
<body>
    <form action="edit.php" method="post">
        <?php if(!isset($_SESSION['username'])){ ?>
            <div class="main-content">
                <div class="icon-home">
                    <a href="home.php"><i class='bx bx-home' ></i></a>
                </div>
                <div class="myprofile">
                    <i class='bx bx-user-circle'></i>
                    <h1>My Profile</h1>
                </div>
                <div class="wrapper">
                    <p class="warning">You are not signed in.</p>
                </div>
            </div>
        <?php } else { ?>
    <div class="main-content">
        <div class="icon-home">
            <a href="home.php"><i class='bx bx-home' ></i></a>
        </div>
        <div class="myprofile">
            <i class='bx bx-trash-circle'></i>
            <h1>My Profile</h1>
        </div>
        <div class="wrapper">
        <?php while($row = mysqli_fetch_assoc($result))
        { ?>
        <?php  if($row['user_Name'] == $_SESSION['username'])
        { ?>
            <div class="username-password">
                <p><input type="hidden" name="id" value="<?php echo $row['user_id'];?>">
                    Username : <input type="hidden" name="name" value="<?php echo $row['user_Name'];?>"><?php echo $row['user_Name'];?> <br>
                    Password : <input type="hidden" name="pass" value="<?php echo $row['user_password'];?>"><?php echo $row['user_password'];?>
                </p>
            </div>
            <div class="information">
                <p> Full Name : <input type="hidden" name="fname" value="<?php echo $row['user_FullName'];?>"><?php echo $row['user_FullName'];?>
                <p> Email : <input type="hidden" name="email" value="<?php echo $row['user_email'];?>"><?php echo $row['user_email'];?></p>
                <p> Telephone : <input type="hidden" name="tel" value="<?php echo $row['user_phone_number'];?>"><?php echo $row['user_phone_number'];?></p>
            </div>
            <div class="btn">
                <button type="submit">Edit information</button>
            </div>
        <?php }}?>
        </div>
        <?php } ?>
    </div>
</form>
</body>
</html>