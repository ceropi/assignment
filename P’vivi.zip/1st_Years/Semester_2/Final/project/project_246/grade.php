<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <link rel="stylesheet" href="grade.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <title>Grade</title>
</head>
<body>
    <div class="header">
        <div class="header-logo">
            <a href="home.php"><img src="image/Logo.png" width="50px" height="50px"></a>
            <p><a href="home.php">LearnHUB.</a></p>
        </div>
        <div class="header-menu">
            <ul>
                <li><a href="home.php">Home</a></li>
                <li><a href="course.php">Course</a></li>
                <li><a href="grade.php">Grade</a></li>
                <li><a href="contact.php">Contact</a></li>
            </ul>
        </div>
        <div class="header-icon">
            <a href="myprofile.php"><i class='bx bx-user-circle'></i></a>
        </div>
    </div>

    <?php   
            require_once "login_db.php";
            require_once "config.php" ;
            if(!isset($_SESSION['username'])){ ?>
                <div class="wrapper">
                    <p class="warning">You are not signed in.</p>
                </div>
    <?php }  else { ?>
        <div class="main-content">
            <h2>Calculate grade</h2>
            <form action="grade_result.php" method="post">
                <div class="input">
                        <table>
                        <tr>
                        <td><label for="text">Math:</label></td>
                        <td><input type="text" name="math" placeholder="input your grade" require></td>
                        </tr>
                        <tr>
                        <td><label for="text">Science:</label></td>
                        <td><input type="text" name="science" placeholder="input your grade" require></td>
                        </tr>
                        <tr>
                        <td><label for="text">English:</label></td>
                        <td><input type="text" name="eng" placeholder="input your grade" require></td>
                        </tr>
                        <tr>
                        <td><label  abel for="text">Social:</label></td>
                        <td><input type="text" name="social" placeholder="input your grade" require></td>
                        </tr>
                        <tr>
                        <td><label for="text">Thai:</label></td>
                        <td><input type="text" name="thai" placeholder="input your grade" require></td>
                        </tr>
                        <tr>
                        <td><label for="text">Physical Education:</label></td>
                        <td><input type="text" name="pe" placeholder="input your grade" require></td>
                        </tr>
                        </table>
                        <div class="button">
                            <input type="submit" value="Calculate" class="btn">
                        </div>
                </div>
            </form>
        </div>
    <?php } ?>
</body>
</html>