<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <link rel="stylesheet" href="grade_result.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <title>Grade</title>
</head>
<body>
    <div class="header">
        <div class="header-logo">
            <a href="home.php"><img src="image/Logo.png" width="50px" height="50px"></a>
            <p><a href="home.php">LearnHUB.</a></p>
        </div>
        <div class="header-menu">
            <ul>
                <li><a href="home.php">Home</a></li>
                <li><a href="course.php">Course</a></li>
                <li><a href="grade.php">Grade</a></li>
                <li><a href="contact.php">Contact</a></li>
            </ul>
        </div>
        <div class="header-icon">
            <a href="myprofile.php"><i class='bx bx-user-circle'></i></a>
        </div>
    </div>
    <?php
        $math = $_POST['math'];
        $science = $_POST['science'];
        $eng = $_POST['eng'];
        $social = $_POST['social'];
        $thai = $_POST['thai'];
        $pe = $_POST['pe'];

        if (empty($math) || empty($science) || empty($eng) || empty($social) || empty($thai) || empty($pe)){
            echo "Error: Input missing!!";
            header('location: grade.php');
        }
        elseif (!is_numeric($math) || !is_numeric($science) || !is_numeric($eng) || !is_numeric($social) || !is_numeric($thai) || !is_numeric($pe)){
            echo "Error: Input missing!!";
            header('location: grade.php');
        }
            
        $result = (($math*3)+($eng*3)+($science*3)+($social*3)+($thai*3)+($pe*3))/18;
    ?>
    <div class="main-content">
    <h2>Calculate grade</h2>
            <div class="input">
                <table>
                <tr>
                <td><label for="text">Math:</label></td>
                <td><p><?php echo number_format($math,2); ?></p></td>
                </tr>
                <tr>
                <td><label for="text">Science:</label></td>
                <td><p><?php echo number_format($science,2); ?></p></td>
                </tr>
                <tr>
                <td><label for="text">English:</label></td>
                <td><p><?php echo number_format($eng,2); ?></p></td>
                </tr>
                <tr>
                <td><label for="text">Social:</label></td>
                <td><p><?php echo number_format($social,2); ?></p></td>
                </tr>
                <tr>
                <td><label for="text">Thai:</label></td>
                <td><p><?php echo number_format($thai,2); ?></p></td>
                </tr>
                <tr>
                <td><label for="text">Physical Education:</label></td>
                <td><p><?php echo number_format($pe,2); ?></p></td>
                </tr>
                </table>
                <div class="show">
                    <p>Your GPA : <?php echo number_format($result,2);?></p><br>
                    <a href="grade.php">Reset</a>
                </div>
            </div>
    </div>
</body>
</html>

