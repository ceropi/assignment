<?php
    session_start();
    include('config.php');

    $errors = array();

    if (isset($_POST['reg_user'])) {
        $fullname = mysqli_real_escape_string($conn, $_POST['fullname']);
        $username = mysqli_real_escape_string($conn, $_POST['username']);
        $email = mysqli_real_escape_string($conn, $_POST['email']);
        $phone = mysqli_real_escape_string($conn, $_POST['phone']);
        $password = mysqli_real_escape_string($conn, $_POST['password']);
        $confirm = mysqli_real_escape_string($conn, $_POST['confirm']);

        if (empty($fullname)) {
            array_push($errors, "Full name is required");
        }
        if (empty($username)) {
            array_push($errors, "Username is required");
        }
        if (empty($email)) {
            array_push($errors, "Email is required");
        }
        if (empty($phone)) {
            array_push($errors, "Phone number is required");
        }
        if ($password != $confirm) {
            array_push($errors, "The two passwords do not match");
        }

        $user_check_query = "SELECT * FROM user WHERE user_Name = '$username' OR user_email = '$email' ";
        $query = mysqli_query($conn, $user_check_query);
        $result = mysqli_fetch_assoc($query);

        if ($result) { // if user exists
            if ($result['user_Name'] == $username) {
                array_push($errors, "Username already exists");
            }
            if ($result['user_email'] == $email) {
                array_push($errors, "Email already exists");
            }
        }

        if (count($errors) == 0) {
            $sql = "INSERT INTO user (user_FullName, user_Name, user_email, user_phone_number, user_password, user_level) VALUES ('$fullname', '$username', '$email', '$phone', '$password','1')";
            mysqli_query($conn, $sql);

            $_SESSION['username'] = $username;
            $_SESSION['success'] = "You are now logged in";
            header('location: home.php');
        }
        else {
            array_push($errors, "Username or Email already exists");
            $_SESSION['error'] = "Username or Email already exists";
            header('location: register.php');
        }
    }
?>