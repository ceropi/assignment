<?php
require "login_db.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <link rel="stylesheet" href="home.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <title>LearnHUB</title>
</head>
<body>
    <div class="header">
        <div class="header-logo">
            <a href="home.php"><img src="image/Logo.png" width="50px" height="50px"></a>
            <p><a href="home.php">LearnHUB.</a></p>
        </div>
        <div class="header-menu">
            <ul>
                <li><a href="home.php">Home</a></li>
                <li><a href="course.php">Course</a></li>
                <li><a href="grade.php">Grade</a></li>
                <li><a href="contact.php">Contact</a></li>
            </ul>
        </div>
        <div class="header-icon">
            <a href="myprofile.php"><i class='bx bx-user-circle'></i></a>
        </div>
    </div>
    <div class="footer">
        <?php if(!isset($_SESSION['username'])){ ?>
            <div class="login-register">
                <a href="login.php"><button type="submit" class="btn">Log in</button></a>
                <a href="register.php"><button type="submit" class="btn">Register</button></a>
             <?php } else { ?>
                <p class="logout">Welcome, <font><?php echo $_SESSION['username']; ?></font></p><br>
                <a href="logout.php"><button type="submit" class="btn_foot"><p class="text">Logout</p></button></a>
             <?php } ?>
            </div>
    </div>
</body>
</html>