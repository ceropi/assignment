<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <title>ENGLISH</title>
</head>
<body>
<div class="header">
        <div class="header-logo">
            <a href="home.php"><img src="image/Logo.png" width="50px" height="50px"></a>
            <p><a href="home.php">LearnHUB.</a></p>
        </div>
        <div class="header-menu">
            <ul>
                <li><a href="home.php">Home</a></li>
                <li><a href="course.php">Course</a></li>
                <li><a href="grade.php">Grade</a></li>
                <li><a href="contact.php">Contact</a></li>
            </ul>
        </div>
        <div class="header-icon">
            <a href="myprofile.php"><i class='bx bx-user-circle'></i></a>
        </div>
    </div>

    <div class="container">
    <h2>English</h2>
    <form action="engdescription.php" method="POST">
    <?php require_once "config.php"; ?>
      <select name="english">
      <?php
            $userQuery = "SELECT * FROM english";
            $result = mysqli_query($conn,$userQuery);
      while($n = mysqli_fetch_assoc($result)) 
      { ?>
          <option value=" <?php echo $n['eng_id']?> "> <?php echo $n['eng_chapter_name']?>   </option>
          <?php } ?>
      </select>
      <br>
      <input type="submit" value="submit">
      <br>
      <a href="course.php">Back to Course</a>
      </from>
    </div>
</body>