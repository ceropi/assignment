<?php
    session_start();
    include('config.php');

    $errors = array();

    if (isset($_POST['login_user'])) {
        $username = mysqli_real_escape_string($conn, $_POST['username']);
        $password = mysqli_real_escape_string($conn, $_POST['password']);

        if (empty($username)) {
            array_push($errors, "Username is required");
        }

        if (empty($password)) {
            array_push($errors, "Password is required");
        }

        $query = "SELECT * FROM user WHERE user_level ='$level'";
        $_SESSION['level']=$level;
        
        if (count($errors) == 0) {
            $query = "SELECT * FROM user WHERE user_Name = '$username' AND user_password = '$password'";
            $result = mysqli_query($conn, $query);

            if (mysqli_num_rows($result) == 1) {
                

                    $row = mysqli_fetch_assoc($result);
                    if (($_POST['username']==$row['user_Name']) && ($_POST['password']==$row['user_password'])){
                        $_SESSION['username'] = $row['user_Name'];
                        $_SESSION['user_level'] = $row['user_level'];
                    }

                header('location: home.php');
            } else {
                array_push($errors, "Wrong username/password combination");
                $_SESSION['error'] = "Wrong username or password try again!";
                header('location: login.php');
            }
        }
    }

?>