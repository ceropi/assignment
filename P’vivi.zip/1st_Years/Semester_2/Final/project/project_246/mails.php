<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <link rel="stylesheet" href="contact.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <title>Mails</title>
</head>
<?php 
require_once "login_db.php";
require_once "config.php" ;
$userQuery = "SELECT * FROM mails";
$result = mysqli_query($conn,$userQuery);
?>
<body>
<body>
    <div class="header">
        <div class="header-logo">
            <a href="home.php"><img src="image/Logo.png" width="50px" height="50px"></a>
            <p><a href="home.php">LearnHUB.</a></p>
        </div>
        <div class="header-menu">
            <ul>
                <li><a href="home.php">Home</a></li>
                <li><a href="course.php">Course</a></li>
                <li><a href="grade.php">Grade</a></li>
                <li><a href="contact.php">Contact</a></li>
            </ul>
        </div>
        <div class="header-icon">
            <a href="myprofile.php"><i class='bx bx-user-circle'></i></a>
        </div>
    </div>

    <div class="mail_in">
    <?php if(!isset($_SESSION['username']))
    { ?>
                <div class="wrapper">
                    <p class="warning">You are not signed in.</p>
                </div>
    <?php }
    elseif($_SESSION['level']==4)
    { ?>
    <h2>Mails</h2>
    <div class="button">
        <a href="contact.php" class="btn-back">Back</a>
    </div>
        <table border="1">
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Message</th>
            </tr>
        <?php while($row = mysqli_fetch_assoc($result)) 
        {?>
            <tr>
            <td><?php echo $row['mail_name'];?></td>
            <td><?php echo $row['mail_email'];?></td>
            <td><?php echo $row['mail_message'];?></td>  
            <td><a href="./delete.php ?id=<?php echo $row['mail_id'];?>">Delete</a></td>
            </tr>
        <?php } } 
        else 
        { ?>
            <div class="wrapper">
                    <p class="warning">You are not Admin.</p>
                </div>
                
        <?php } ?>
        </table>
    </div>
</body>
</html>