<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <link rel="stylesheet" href="contact.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <title>Contact</title>
</head>
<body>

<?php   
    require_once "login_db.php";
    require_once "config.php" ;
    $userQuery = "SELECT * FROM user WHERE user_id";
    $result = mysqli_query($conn,$userQuery);
?>
    <div class="header">
        <div class="header-logo">
            <a href="home.php"><img src="image/Logo.png" width="50px" height="50px"></a>
            <p><a href="home.php">LearnHUB.</a></p>
        </div>
        <div class="header-menu">
            <ul>
                <li><a href="home.php">Home</a></li>
                <li><a href="course.php">Course</a></li>
                <li><a href="grade.php">Grade</a></li>
                <li><a href="contact.php">Contact</a></li>
            </ul>
        </div>
        <div class="header-icon">
            <a href="myprofile.php"><i class='bx bx-user-circle'></i></a>
        </div>
    </div>
    
    <form action="contact_db.php" method="post">
    <?php if(!isset($_SESSION['username'])){ ?>
                <div class="wrapper">
                    <p class="warning">You are not signed in.</p>
                </div>
    <?php }  else { ?>
            <?php while($row = mysqli_fetch_assoc($result)) { 
                    if($row['user_Name'] == $_SESSION['username']) {
                        $_SESSION['level'] = $row['user_level']; 
                    } }
                    if($_SESSION['level']==1){
            ?>
                <div class="main-content">
                    <h1>Contact us</h1>
                    <div class="input-box">
                        <input type="text" name="name" placeholder="Name" required>
                    </div>
                    <div class="input-box">
                        <input type="text" name="email" placeholder="Email" required>
                    </div>
                    <div class="input-message">
                        <textarea placeholder="Message" name="message"></textarea>
                    </div>
                    <div class="submit-cancel">
                        <button type="submit" class="btn-submit_cancel">Submit</button>
                        <button type="reset" class="btn-submit_cancel">Cancel</button>
                    </div>
                
                    <?php }  else { ?>
                    
                    <h1 class="else">Contact us</h1>
                    <div class="input-box">
                        <input type="text" name="name" placeholder="Name" required>
                    </div>
                    <div class="input-box">
                        <input type="text" name="email" placeholder="Email" required>
                    </div>
                    <div class="input-message">
                        <textarea placeholder="Message" name="message"></textarea>
                    </div>
                    <div class="submit-cancel">
                        <button type="submit" class="btn-submit_cancel">Submit</button>
                        <button type="reset" class="btn-submit_cancel">Cancel</button>
                        <a href="mails.php">Mails</a>
                    </div>
                            
                    <?php } } ?>
                
                </div>
    </form>
</body>
</html>