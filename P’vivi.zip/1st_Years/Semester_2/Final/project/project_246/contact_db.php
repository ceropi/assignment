<?php
    require_once "config.php";

    $name = $_POST['name'];
    $email = $_POST['email'];
    $message = $_POST['message'];

    $userQuery = "Insert into mails values (NULL,'$name','$email','$message')";
    $result = mysqli_query($conn,$userQuery);

    if(!$result){
        die("Could not successfully run the query $userQuery".mysqli_error($conn));
    }
    else{
        header("location: contact.php");
    }

mysqli_close($conn)
?>