<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LearnHUB.(form)</title> <link rel="stylesheet" href="form-login.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>

<body>
    <nav>
        <div class="container">
            <div class="nav-con">
                <div class="Logo">
                    <a href="LearnHUB.php">LearnHUB.</a>
                </div>
               <ul class="menu">
                    <li><a href="form_log_in.php">Login <i class='bx bxs-lock-alt' ></i></a></li>
                </ul>
            </div>
        </div>
    </nav>

    <section class="wrapper">
        <div class="wrapper-con">
            <div class="wrapper-con-form">
                <form action="">
                    <div class="form">
                        <h1>Login</h1>
                        <div class="input-box">
                            <input type="text" placeholder="Username" required >
                            <box-icon class='bx bxs-user'></box-icon>
                        </div>
                        <div class="input-box">
                            <input type="text" placeholder="Password" required>
                            <box-icon class='bx bxs-lock-alt'></box-icon>
                        </div>
                    
                        <div class="remember-forget">
                            <label><input type="checkbox">Remember me</label>
                            <a href="#">Forget password?</a>
                        </div>
                        
                        <div class="button">
                            <button type="submit" class="btn">Login</button>
                        </div>
                        
                        <div class="register-link">
                            <p>Don't have an account yet? <a href="register.php">Register</a></p>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </section>

    <script src="https://unpkg.com/boxicons@2.1.4/dist/boxicons.js"></script>
</body>

</html>