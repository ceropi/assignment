<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product summary</title> <link rel="stylesheet" href="summary.css">
</head>
<body>
<div class="header">
        <img src="cat.jpg" width="125px" height="100px">
        <ul>
            <li><a href="">Menu1</a></li>
            <li><a href="">Menu2</a></li>
            <li><a href="">Menu3</a></li>
        </ul>
        <img src="icon.png" width="50px" height="50px" align="right">
    </div>
    <div class="summary">
        <h2>Order Summary</h2>
        <?php
        $qty1 = $_POST['q1'];
        $qty2 = $_POST['q2'];
        $qty3 = $_POST['q3'];
        $shipping = $_POST['select'];
        $totalprice = 0;
        $cost = 0;
        $discount = 0;
        
        
            $totalprice = ($qty1*450)+($qty2*570)+($qty3*630);

            if($shipping=="Flash"){
                $cost = 40;
            }
            elseif($shipping=="EMS"){
                $cost = 50;
            }
            else{
                $cost = 60;
            }
        
            if($totalprice>5000){
                $discount = $totalprice * 0.15;
            }
            elseif($totalprice>3000){
                $discount = $totalprice * 0.10;
            }
            elseif($totalprice>1000){
                $discount = $totalprice * 0.05;
            }
            else{
                $discount = 0;
            }

        function Calprice($a,$b,$c){
            return $a + $b - $c;
        }
        $netPrice = Calprice($totalprice,$cost,$discount);

        ?>
        <p>
            Shipment Type : <font><?= $shipping ?> (<?= $cost ?> THB)</font><br>
            Discount : <font><?= $discount ?></font><br>
            Net Price : <font><?= $netPrice ?> Baht </font><br>
            <b>Thank You Very Much</b>
        </p>
    </div>
</body>
</html>