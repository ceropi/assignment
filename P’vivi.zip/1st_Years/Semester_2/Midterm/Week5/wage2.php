<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wage Report</title> <link rel="stylesheet" href="sample.css">
</head>
<body>
    <h1>Wage Report</h1>
    <?php
        $hourlyWage = $_POST['hourlyWage'];
        $hoursWorked = $_POST['hoursWorked'];
        $wage = Wagecal($hourlyWage, $hoursWorked);

        function Wagecal($hrWage, $hrWork){
            return $hrWage * $hrWork;
        }

        echo "<p>Your hourly wage is $$hourlyWage and you worked $hoursWorked hours. </p>";
        echo "<p>Your Wages are $$wage.</p>"
    ?>
</body>
</html>