<?php
$number1 = $_POST['number1'];
$number2 = $_POST['number2'];
$type = $_POST['type'];
$primeNum = array(2, 3, 5, 7, 11, 13, 17, 19, 23, 29);
$output = 0;

if($type = 'Sum'){
    $output = $number1 + $number2;
    echo "$number1 + $number2 = $output";
}
elseif($type = 'Average'){
    $output = ($number1 + $number2) / 2;
    echo "The average of $number1 , $number2 = $output";
}
else{
    if(($output = $number1 + $number2) == $primeNum){
        echo "$output is Prime number.";
    }
    else{
        echo "$output is not Prime number.";
    }
}
?>