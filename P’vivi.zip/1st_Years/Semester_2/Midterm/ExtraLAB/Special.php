<?php
$first = $_POST['fnum']; 
$last = $_POST['lnum']; 
$method = $_POST['method'];

function check_prime($num)
{
   if ($num == 1)
   return 0;
   for ($i = 2; $i <= $num/2; $i++)
   {
      if ($num % $i == 0)
      return 0;
   }
   return 1;
}
switch($method){
    case("sum"):
        $total = 0;
        for($i=$first;$i <= $last;$i++){
            $total = $total + $i;
        }
        echo "Sum numbers is $total";
        break;
    case("avg"):
        $n = 0;
        $total = 0;
        for($i=$first;$i <= $last;$i++){
            $total = $total + $i;
            $n++;
        }
        $avg = $total / $n;
        echo "Average numbers is $avg";
        break;
    case("pri"):
        for($i=$first;$i <= $last;$i++){
            if(check_prime($i)==1){
                $arr[] = $i;
            }
        }
        echo "Prime numbers is ";
        foreach($arr as $num){
            echo "$num ";
        }
        break;
    
}

?>