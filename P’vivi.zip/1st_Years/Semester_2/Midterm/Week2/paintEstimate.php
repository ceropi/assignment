<?php
#receive
$lenght = $_POST['roomlenght'];
$width = $_POST['roomwidth'];
$height = $_POST['roomheight'];
$space = 0;
$priceColors = 0;
$priceLabor = 0;
$totalPrice = 0;


#cal space of room
$space = (($lenght*$height)*2) + (($width*$height)*2) + ($lenght * $width);

#cal price of colors
$priceColors = ($space / 400) * 17;

#cal price of labor cost
$priceLabor = ($space / 200) * 25;

#cal total price
$totalPrice = $priceColors + $priceLabor;

#show info
echo "<h1>King Painting</h1>";
echo "Lenght of the room : $lenght square feet<br>";
echo "Width of the room : $width square feet<br>";
echo "Height of the room : $height aquare feet<br>";
echo "Total area of the room : $space aquare feet<br>";
echo "Paint cost : $priceColors dollars<br>";
echo "Labor cost : $priceLabor dollars<br>";
echo "Total cost : $totalPrice dollars";
?>