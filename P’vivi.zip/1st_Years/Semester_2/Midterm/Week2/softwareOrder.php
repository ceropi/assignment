<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Software Order</title>
</head>
<body>
    <h3>Save the world : order details</h3>
    <?php
        #receive
        $select = $_POST['os'];
        $numcopies = $_POST['numCopies'];
        $copiesCell = 0;
        $tax = 0;
        $charge = 0;
        $subTotal = 0;

        if (empty($numcopies)){
            echo "Error: Input missing!!";
        }
        elseif (!is_numeric($numcopies)){
            echo "Error: Input missing!!";
        }
        else{
            #cal copies cells
            $copiesCell = $numcopies * 35;

            #cal tax
            $tax = $copiesCell * 0.07;

            #cal charge
            if($numcopies < 5){
                $charge = 3.5;
            }
            else{
                $charge = 3.5 + (($numcopies - 4) * 0.75);
            }
            #cal sub total
            $subTotal = $copiesCell + $tax + $charge;

            #show info
            echo "Operating system : $select<br>";
            echo "The number of copies is $numcopies<br>";
            echo "=========================<br>";
            echo "The sub-total : $".number_format($copiesCell,2)."<br>";
            echo "The tax 7% : $".number_format($tax,2)."<br>";
            echo "The shipping / handling : $".number_format($charge,2)."<br>";
            echo "=========================<br>";
            echo "Total cost : $".number_format($subTotal,2);
        }


    ?>
</body>
</html>