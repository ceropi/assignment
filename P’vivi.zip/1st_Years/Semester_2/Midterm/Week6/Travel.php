<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Travel</title> <link rel="stylesheet" href="imported.css">
</head>
<body>
<div class="container">
    <h1>Travel Reservation Report</h1>
    <?php
        $select = $_POST['travel'];
        $numberOfpeople = $_POST['numberOfpeople'];
        $numberOfstaying = $_POST['numberOfstaying'];
        $airline = 0;
        $hotel = 0;
        $totalCost = 0;

        if (empty($numberOfpeople) || empty($numberOfstaying)){
            echo "Error: Input missing!!";
        }
        elseif (!is_numeric($numberOfpeople) || !is_numeric($numberOfstaying)){
            echo "Error: Input missing!!";
        }
        else{
            
            if($select == 'Bacelona'){
                $airline = $numberOfpeople * 875;
                $hotel = $numberOfstaying * 85;
            }
            if($select == 'Cairo'){
                $airline = $numberOfpeople * 950;
                $hotel = $numberOfstaying * 98;
            }
            if($select == 'Rome'){
                $airline = $numberOfpeople * 875;
                $hotel = $numberOfstaying * 110;
            }
            if($select == 'Santiago'){
                $airline = $numberOfpeople * 820;
                $hotel = $numberOfstaying * 85;
            }
            if($select == 'Tokyo'){
                $airline = $numberOfpeople * 1575;
                $hotel = $numberOfstaying * 240;
                if($numberOfstaying >= 5){
                    $airline = $numberOfpeople * (1575 - 200);
                }
            }
            
            $totalCost = $airline + $hotel;

            echo "Destination : $select <br>";
            echo "Number of people : $numberOfpeople <br>";
            echo "Number of night : $numberOfstaying <br>";
            echo "Airline Tickets : $$airline <br>";
            echo "Hotel Charges : $$hotel <br>";
            echo "<font>Total Cost : $$totalCost</font><br>";
        }
    ?>
    </div>
</body>
</html>
